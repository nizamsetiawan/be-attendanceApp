# jQuery PWStrength #

PWStrength is a jQuery plugin to indicate the strength of passwords.

## Usage & Demo ##

http://matoilic.github.com/jquery.pwstrength

## Version History ##

**0.1**

* initial release

**0.1.1**

* updated plugin specification for the jquery plugin repository

## Licence ##

Copyright &copy; 2013 Mato Ilic <<info@matoilic.ch>>

jquery.placeholder is dual licensed under the MIT and GPL licenses:

* http://www.opensource.org/licenses/mit-license.php 
* http://www.gnu.org/licenses/gpl.html